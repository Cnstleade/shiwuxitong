var HzInterface = {

//   /*密码修改*/
//   modifyPassword: '/user/updatePassword',

//   /*查询左侧树*/
//   queryLeftMenu: '/menu/getUserMenu',

//   /*查询短信列表接口*/
//   querySelectTbable: '/selectTable',

//   /*保存短信编辑接口*/
//   saveMessage: '/updateMessageAll',

//   /*撤销短信内容接口*/
//   repealMessage: '/deleteData',

//   /*删除短信列表接口*/
//   deleteData: '/deleteData',

//   /*短信模板下载*/
//   downloadMsgTemplete: '/common/msgTemplateDownload',

//   /*事务管理列表*/
//   queryAffairTable: '/selectAffairTable',

//   /*新增事务接口*/
//   addAffair: '/insertAffair',

//   /*修改事务接口*/
//   modifyAffair: '/updateAffair',

//   /*查询事务日志列表*/
//   queryAfairLog: '/selectAffairLogging',

//   /*删除事务日志*/
//   deleteAfairLog: '/delectAffairLogging',

//   /*事务完成*/
//   completeAffair: '/insertAffairLogging',

//   /*成员列表查询*/
//   queryPeopleList: 'user/UserNamelist',

//   /*查询用户列表*/
//   queryUserList: '/user/list',

//   /*新增用户信息*/
//   addUserInfo: '/user/add',

//   /*修改用户信息*/
//   modifyUserInfo: '/user/update',

//   /*删除用户信息*/
//   deleteUserInfo: '/user/delete',

//   /*获取用户权限*/
//   getUserAuthority: '/role/roleNamelist',

//   /*获取部门列表*/
//   getSectionList: '/dept/deptNamelist',

//   /*查询营销短信*/
//   queryMarkMessage: '/selectMarketingMsg',

//   /*查看已发送营销号码*/
//   lookSendOperatorMsg: '/selectByMarketingMsg',

//   /*发送短信*/
//   sendOperatorMessages: '/sendMarketMsg',

//   /*日志列表*/
//   logTableSelect: '/log/list',

//   /*权限列表*/
//   roleList: '/role/list',

//   /*新增权限*/
//   addRole: '/role/add',

//   /*保存新增权限*/
//   addUserRole: '/role/Useraddlist',

//   /*删除权限*/
//   deleteRole: '/role/delete',

//   /*保存删除权限*/
//   deleteUserRole: '/role/Userdeletelist',

//   /*菜单列表*/
//   menuList: '/menu/list',

//   /*用户列表*/
//   queryUserRoleList: '/role/Userlist',

//   /*修改角色权限*/
//   editRole: '/role/getRoleMenu',

//   /*保存修改角色权限*/
//   saveEditRole: 'role/update'



};

export default {
  HzInterface
}
